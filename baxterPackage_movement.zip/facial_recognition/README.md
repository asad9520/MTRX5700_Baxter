  <br/>1.Please Add this folder to the <your_ws>/src, and:<br/>
  <br/>cd ~/<your_ws><br/>
  <br/>catkin build<br/>
  <br/>After doing this:<br/>
  <br/>2.roscore<br/>
  <br/>3.launch the environment (source is needed before executing this command):<br/>
  <br/>roslaunch baxter_gazebo baxter_world.launch<br/>
  <br/>4.rosrun (source is needed before executing this command):<br/>
  <br/>rosrun facial_recognition facial_node.py<br/>
  
  <br/>If works, the image of right hand camra will be shown in the cv window.
