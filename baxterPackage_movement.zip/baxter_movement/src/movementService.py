#!/usr/bin/env python

import rospy
import sys
import actionlib

import argparse
import struct

from geometry_msgs.msg import (
    PoseStamped,
    Pose,
    Point,
    Quaternion,
)
from std_msgs.msg import Header

from baxter_core_msgs.srv import (
    SolvePositionIK,
    SolvePositionIKRequest,
)


from baxter_movement.msg import BaxterActionFeedback, BaxterActionResult, BaxterActionAction, BaxterActionGoal, BaxterHeadFeedback, BaxterHeadResult, BaxterHeadAction, BaxterHeadGoal
from baxter_movement.srv import *
from baxter_pykdl import baxter_kinematics


def feedback(fb, fb2):
	None


def handle_motion_request(req):
	# finish the motion
	# if it was successfully done
	#trigReq= TriggerRequest()
	goal = BaxterActionGoal()
	headgoal = BaxterHeadGoal()

	#ironman position
	if req.data == 0 :
		goal.coordinates = [-1.1,0.3,2.95,1.8,0.19,-1.57, -3.05]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [0,1,0,0,0,0,0]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()

	#hello movement
	if req.data == 1 :
		goal.coordinates = [-1.1,0.3,2.95,1.8,0.19,-1.57, -3.05]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)

		for _move in range(3):
			goal.coordinates = [-0.459,-0.202,1.807,1.714,-0.906,-1.545,-0.276]
			goal.precision = 0.2
			RHandClient.send_goal(goal, feedback)
			RHandClient.wait_for_result()
			goal.coordinates = [-0.395,-0.202,1.831,1.981,-1.979,-1.100,-0.448]
			goal.precision = 0.2
			RHandClient.send_goal(goal, feedback)
			RHandClient.wait_for_result()

		LHandClient.wait_for_result()
		headClient.wait_for_result()

	#handshake movement
	if req.data == 2 :
		goal.coordinates = [-1.1,0.3,2.95,1.8,0.19,-1.57, -3.05]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		for _move in range(4):
			goal.coordinates = [0.5,-0.4,0.4,1.55,-0.4,-1.15,-1.7]
			goal.precision = 0.1
			RHandClient.send_goal(goal, feedback)
			RHandClient.wait_for_result()
			goal.coordinates = [0.5, -0.4,0.4,1.35,-0.4,-0.7,-1.7]
			goal.precision = 0.1
			RHandClient.send_goal(goal, feedback)
			RHandClient.wait_for_result()
		LHandClient.wait_for_result()
		headClient.wait_for_result()

	# dab movement
	if req.data == 3 :
		goal.coordinates = [1,-0.7,0,0,0,0,0]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [1,0,2.2,1.5,0,0,0]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0.8
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()

	# Hug
	if req.data == 4 :
		goal.coordinates = [-0.2,-1,-1.6,0.2,0,0.2,-0.448]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [0.2,-1,1.6,0.2,0,0.2,-0.276]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()
		rospy.sleep(5)
		goal.coordinates = [-0.25,0.2,-1.6,0.55,0,0.7,-0.448]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [0.25,0.2,1.6,0.55,0,0.7,-0.276]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()
		goal.coordinates = [-0.45,0.2,-1.6,0.35,0,1,-0.448]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [0.45,0.2,1.6,0.5,0,1.3,-0.276]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()
		goal.coordinates = [0.2,0.2,-1.6,0.35,0,1,-0.448]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [-0.2,0.2,1.6,0.5,0,1.3,-0.276]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()
		goal.coordinates = [-0.2,1,-1.6,0.2,0,0.2,-0.448]
		goal.precision = 0.1
		LHandClient.send_goal(goal, feedback)
		goal.coordinates = [0.2,1,1.6,0.2,0,0.2,-0.276]
		goal.precision = 0.1
		RHandClient.send_goal(goal, feedback)
		headgoal.angle = 0
		headgoal.speed = 0.1
		headClient.send_goal(headgoal,feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()

	# Egyptian Dance
	if req.data == 5 :
		goal.coordinates = [-0.8,0,0,1.8,0,-1.7,0]
		goal.precision = 0.15
		RHandClient.send_goal(goal, feedback)
		goal.coordinates = [0.8,0,3.2,1.8,0,-1.7,0]
		goal.precision = 0.15
		LHandClient.send_goal(goal, feedback)
		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		for _move in range(5):
			goal.coordinates = [-0.8,0,0,1.2,0,-1.3,0]
			goal.precision = 0.15
			RHandClient.send_goal(goal, feedback)
			goal.coordinates = [0.8,0,3.2,1.2,0,-1.3,0]
			goal.precision = 0.15
			LHandClient.send_goal(goal, feedback)
			headgoal.angle = 0.8
			headgoal.speed = 0.1
			headClient.send_goal(headgoal,feedback)
			headClient.wait_for_result()
			RHandClient.wait_for_result()
			LHandClient.wait_for_result()
			goal.coordinates = [-0.8,0,0,1.8,0,-1.7,0]
			goal.precision = 0.15
			RHandClient.send_goal(goal, feedback)
			goal.coordinates = [0.8,0,3.2,1.8,0,-1.7,0]
			goal.precision = 0.15
			LHandClient.send_goal(goal, feedback)
			headgoal.angle = -0.8
			headgoal.speed = 0.1
			headClient.send_goal(headgoal,feedback)
			headClient.wait_for_result()
			RHandClient.wait_for_result()
			LHandClient.wait_for_result()

		LHandClient.wait_for_result()
		RHandClient.wait_for_result()
		headClient.wait_for_result()

	# inverse kinematics to move arm to desired pose
	if req.data == 6:

		kin = baxter_kinematics('right')
		pos = [0.582583, -0.180819, 0.216003]
		rot = [0.03085, 0.9945, 0.0561, 0.0829]

		joint_states = kin.inverse_kinematics(pos,rot)
		print('\n')
		print(joint_states)
		joint_states = joint_states * 3.142 / 180
		print(joint_states)

		goal.coordinates = joint_states
		goal.precision = 0.12
		RHandClient.send_goal(goal, feedback)
		RHandClient.wait_for_result()


	# do your motion planning here
	if (1==1): # You should decide when the robot has finished moving.
		print "Hey, the motion planning was done correctly"
		res.success = True
		res.message = "Baxter has completed an action"
	else:
		print "How come??"
		res.success = False
		res.message = "Baxter did not complete an action"

	return res



res = BaxterMotionResponse()
rospy.init_node('baxter_motion_server')
LHandClient = actionlib.SimpleActionClient ('/Lhand_server', BaxterActionAction)
RHandClient = actionlib.SimpleActionClient ('/Rhand_server', BaxterActionAction)
headClient = actionlib.SimpleActionClient ('/Head_server', BaxterHeadAction)
motion_srv = rospy.Service('baxtermotion_server', BaxterMotion, handle_motion_request)
LHandClient.wait_for_server()
RHandClient.wait_for_server()
headClient.wait_for_server()

print "movement server ready and spinning."


rospy.spin()
