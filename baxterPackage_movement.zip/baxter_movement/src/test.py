#!/usr/bin/env python

from baxter_movement.msg import BaxterActionGoal, BaxterActionResult, BaxterActionFeedback 
 
print('OK, it worked!!!')
